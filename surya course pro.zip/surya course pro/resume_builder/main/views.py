from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .forms import UserRegisterForm, ResumeForm
from .models import Resume
from django.contrib.auth import login
from .forms import CustomUserCreationForm

from .forms import ResumeForm 
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.http import HttpResponse
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from .models import Resume

def download_resume_pdf(request, resume_id):
    resume = Resume.objects.get(id=resume_id)

    # Create the HTTP response with PDF headers
    response = HttpResponse(content_type="application/pdf")
    response["Content-Disposition"] = f'attachment; filename="{resume.full_name}_resume.pdf"'

    # Create PDF
    p = canvas.Canvas(response, pagesize=letter)
    width, height = letter

    # Title
    p.setFont("Helvetica-Bold", 16)
    p.drawString(200, height - 50, f"{resume.full_name}'s Resume")

    p.setFont("Helvetica", 12)
    y = height - 100

    # Resume details
    p.drawString(50, y, f"Email: {resume.email}")
    y -= 20
    p.drawString(50, y, f"Phone: {resume.phone}")
    y -= 20
    

    p.setFont("Helvetica-Bold", 14)
    p.drawString(50, y, "Education:")
    y -= 20
    p.setFont("Helvetica", 12)
    p.drawString(70, y, resume.education)
    y -= 40

    p.setFont("Helvetica-Bold", 14)
    p.drawString(50, y, "Experience:")
    y -= 20
    p.setFont("Helvetica", 12)
    p.drawString(70, y, resume.experience)
    y -= 40

    p.setFont("Helvetica-Bold", 14)
    p.drawString(50, y, "Skills:")
    y -= 20
    p.setFont("Helvetica", 12)
    p.drawString(70, y, resume.skills)

    # Save PDF
    p.showPage()
    p.save()

    return response




def register(request):
    if request.method == "POST":
        form = UserRegisterForm(request.POST)   # ✅ changed
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect("dashboard")
    else:
        form = UserRegisterForm()               # ✅ changed
    return render(request, "register.html", {"form": form})

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('dashboard')  # Or use request.GET.get('next', 'dashboard')
        else:
            return render(request, 'login.html', {'error': 'Invalid username or password'})
    return render(request, 'login.html')


def home(request):
    return render(request, 'home.html')

@login_required
def dashboard(request):
    resumes = Resume.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'dashboard.html', {'resumes': resumes})


from .forms import ResumeForm

@login_required
def create_resume(request):
    if request.method == 'POST':
        form = ResumeForm(request.POST, request.FILES)
        if form.is_valid():
            resume = form.save(commit=False)  # don't save to DB yet
            resume.user = request.user        # assign the logged-in user
            resume.save()                     # now save to DB
            return redirect('dashboard')
    else:
        form = ResumeForm()
    return render(request, 'create_resume.html', {'form': form})

@login_required
def view_resume(request, pk):
    resume = get_object_or_404(Resume, pk=pk, user=request.user)
    return render(request, 'view_resume.html', {'resume': resume})
